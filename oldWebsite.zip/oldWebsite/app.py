# app.py
import os
import socket

from flask import (
    Flask, render_template, request,
    redirect, url_for, send_file, Response
)
from werkzeug.utils import secure_filename

import anno_img
import anno_liv
from flask import request, jsonify
from waitress import serve


app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
OUTPUT_FOLDER = 'outputs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['OUTPUT_FOLDER'] = OUTPUT_FOLDER

@app.route('/')
def root():
    return redirect(url_for('login'))

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/index.html')
def dashboard():
    return render_template('index.html')

@app.route('/detect_image', methods=['POST'])
def detect_image():
    f = request.files['image']
    filename = secure_filename(f.filename)

    if not anno_img.is_allowed_file(filename):
        return "Unsupported file type.", 400

    ext = filename.rsplit('.', 1)[1].lower()
    image_bytes = f.read()

    annotated_io, mime_type = anno_img.annotate_image_bytes(image_bytes, ext, conf_threshold=0.75)


    return send_file(
        annotated_io,
        mimetype=mime_type,
        as_attachment=True,
        download_name=f'annotated.{ext}'
    )

@app.route('/detect_video', methods=['POST'])
def detect_video():
    f = request.files['video']
    video_bytes = f.read()

    from anno_vid import annotate_video_bytes
    annotated_io, mime_type = annotate_video_bytes(video_bytes)

    return send_file(
        annotated_io,
        mimetype=mime_type,
        as_attachment=True,
        download_name='annotated_video.mp4'
    )

@app.route('/livestream')
def livestream_page():
    return render_template('livestream.html')

@app.route('/video_feed')
def video_feed():
    # uses the generator from anno_liv
    return Response(
        anno_liv.frame_generator(),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )

@app.route("/annotate_frame", methods=["POST"])
def annotate_frame():
    frame = request.files.get("frame")
    if not frame:
        return "No frame received", 400

    frame_bytes = frame.read()
    try:
        from anno_liv import detect_objects_from_bytes
        detections = detect_objects_from_bytes(frame_bytes)
    except Exception as e:
        return {"error": str(e)}, 500

    return jsonify(detections)

if __name__ == "__main__":
    #New line to run client to server side connection
    PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
    print(f"Project root is: {PROJECT_ROOT}")
    #Old run line to run on one computer
    #app.run(debug=True)
 # Get local IP address
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
    except Exception:
        local_ip = '127.0.0.1'
    finally:
        s.close()

    print(f"\n➡️  Listening on all interfaces (host=0.0.0.0) port=5000")
    print(f"🔗  Access this app from another device on your LAN at:")
    print(f"   http://{local_ip}:5000\n")

    serve(app, host="0.0.0.0", port=5000)